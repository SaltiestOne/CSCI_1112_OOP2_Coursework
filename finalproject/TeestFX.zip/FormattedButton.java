import javafx.scene.control.Button;


/**
 * Subclass of Button that automatically 
 * formats itself using the static parameters 
 * defined in the Formatter object, pontentially
 * including Font, font size, and color. It and 
 * its subclasses cannot be instantiated until
 * all necessary parameters have been defined
 * in Formatter.
 * 
 * @author Kayden Barlow
 */
public class FormattedButton extends Button	{

	/**
	 * Constructor for instances of the 
	 * FormattedButton class. Creates a 
	 * Button with the input text, with the
	 * Font, main Color, and default text 
	 * size defined in the Formatter object.
	 * 
	 * @param text String of the Button's text.
	 */
	FormattedButton(String text) {
		
		super(text);
		this.setFont(Formatter.getFont());
		this.setTextFill(Formatter.getMainColor());
		this.setBackground(null);
	}
	
	/**
	 * Constructor for instances of the 
	 * FormattedButton class. Creates a 
	 * Button with the input text and font size,
	 * with the Font and main Color  
	 * defined in the Formatter object.
	 * 
	 * @param text String of the Button's text.
	 * @param int Integer font size of the 
	 * Button's text.
	 */
	FormattedButton(String text, int size) {
		
		super(text);
		this.setFont(Formatter.getFont(size));
		this.setTextFill(Formatter.getMainColor());
		this.setBackground(null);
	}
	
	/**
	 * No-arg Constructor for instances of the 
	 * FormattedButton class. Creates a 
	 * Button without text and with the
	 * Font, main Color, and default text 
	 * size defined in the Formatter object.	 * 
	 */
	FormattedButton() {
		
		super();
		this.setFont(Formatter.getFont());
		this.setTextFill(Formatter.getMainColor());
		this.setBackground(null);
	}
}
