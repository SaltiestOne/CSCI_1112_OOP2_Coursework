/**
 * A subclass of Skill intended for the 
 * Hero's basic, no-cost attack. Defined as
 * a subclass of Skill to take advantage of
 * similarities in formatting, but ignores 
 * any Cooldown restrictions of its parent.
 * 
 * @author Kayden Barlow
 */
class BasicAttack extends Skill {
	
	
	/**
	 * Basic Attack has a set name, never
	 * increases Cooldown, and is always learned.
	 * Invokes the "incidental" Action constructor,
	 * and is thus never added to the allActions list.
	 * 
	 * @param gear Gear object from which 
	 * BasicAttack's scaling is derived. 
	 * @param message String of the text which will be displayed when the Skill
	 * is used. Placeholders for the implement, target, and damage when used are
	 * [i], [t], and [d] respectively and are replaced by output methods.
	 */
	BasicAttack(Gear gear, String message) {
		
		super("Attack", 0, 0, gear, message);
	}
	
	
	/**
	 * As a basic attack does not have any
	 * resource or usability conditions, its 
	 * name alone suffices for a selection message.
	 * 
	 * @return String of the BasicAttack's name
	 * (should be "Attack", as per
	 * the constructor).
	 */
	String menuMessage() {
		
		return this.getName();
	}
	
	/**
	 * Returns True regardless of the normal factors
	 * defined in the Skill superclass. A basic attack
	 * should always be learned and usable regardless
	 * of current Cooldown.
	 * 
	 * @return True, always.
	 */
	boolean isUsable() {
		
		return true;
	}
	
	
	/**
	 * Empty override of superclass method
	 * to ensure that BasicAttack cannot
	 * be unlearned.
	 */
	void unlearn() {

	}
}
