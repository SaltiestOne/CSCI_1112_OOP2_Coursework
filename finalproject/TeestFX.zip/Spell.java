/**
 * A subclass of Action intended to represent
 * the various magical spells that the Hero can
 * cast. Uses a classic "Mana" system, where
 * an amount of resource is available at the
 * start of a fight, with different Spell
 * objects costing a specified amount of it.
 * 
 * @author Kayden Barlow
 */
class Spell extends Action {
	
	/**
	 * Constructor for "permanent" instances of
	 * the Spell object.
	 * 
	 * @param name String of the Spell's name.
	 * @param manaCost Integer of the amount of Mana spent by the Spell.
	 * @param gear The Stat object from which the Spell's scaling is derived.
	 * @param message String of the text which will be displayed when the Spell
	 * is used. Placeholders for the implement, target, and damage when used are
	 * [i], [t], and [d] respectively and are replaced by output methods.
	 * @param learned Boolean value indicating if the player has "learned" this
	 * Spell after its creation. If False, the Spell cannot be used regardless 
	 * of other factors.
	 */
	Spell(String name, int manaCost, Stat stat, String message, boolean learned) {
		
		super(name, manaCost, stat, message, learned);
	}
	
	
	/**
	 * Constructor for "incidental" instances of
	 * the Spell object.
	 * 
	 * @param name String of the Spell's name.
	 * @param id Integer identifying number of the Spell.
	 * @param manaCost Integer of the amount of Mana spent by the Spell.
	 * @param gear Stat object from which the Spell's scaling is derived.
	 * @param message String of the text which will be displayed when the Spell
	 * is used. Placeholders for the implement, target, and damage when used are
	 * [i], [t], and [d] respectively and are replaced by output methods.
	 */
	Spell(String name, int id, int cost, Stat stat, String message) {
		
		super(name, id, cost, stat, message);
	}
	
	/**
	 * If this Spell is marked learned, returns
	 * a String containing the Spell's name and 
	 * Mana cost. If this Spell is unlearned, 
	 * returns "[UNLEARNED]".
	 */
	String menuMessage() {
		
		if (this.isLearned()) {
		
				return (this.getName() + "\n" + 
				this.getCost() + "/" + getMana() + " Mana");
			
		} else {
			
			return ("[UNLEARNED]");
		}
	}
	
	
	/**
	 * Indicates if this Spell can be used.
	 * If this Spell costs more mana than is 
	 * available, or if it is unlearned,
	 * returns False. Otherwise, returns True.
	 */
	boolean isUsable() {
		
		if (getMana() >= this.getCost()) {
			
			return this.isLearned();
		} else {
			
			return false;
		}
	}
	
	
	/**
	 * Returns the static value indicating
	 * the Hero's maximum Mana.
	 * 
	 * @return Integer maximum Mana.
	 */
	int getMaxMana() {
		
		return ((Hero)getUser()).getMaxMana();
	}
	
	
	
	/**
	 * Returns the integer value of the
	 * Hero's available Mana.
	 * 
	 * @return Integer of available Mana.
	 */
	int getMana() {
		
		return ((Hero)getUser()).getMana();
	}
	
	
	/**
	 * Attempts to reduce current Mana by
	 * this Spell's cost value. Invokes the
	 * static Spell method, which throws an
	 * exception if cost exceeds current mana.
	 */
	void spendMana() {

		((Hero)getUser()).spendMana(this.getCost());
	}
	
	/**
	 * Method used to provide String descriptions
	 * for exceptions thrown as a result of invalid
	 * Spells. Provides messages in the cases that 
	 * the Mana cost exceeds what is available,
	 * that it is unlearned, and a failsafe in case 
	 * this method gets called in any other 
	 * circumstance. 
	 */
	public String errorMessage() {
		
		if (!isLearned()) {
			
			return ("Spell not yet learned.");
		} else if (getMana() < getCost()) {
			
			return ("Insufficient Mana!");
		} else  {
			
			return (getName() + " is unusable for some reason...");
		}
	}
	
	
	/**
	 * Consolidates damaging a target with a Spell (using
	 * the integer and Fighter input values), spending 
	 * its Mana cost, and generating its output message 
	 * (also using the inputs). This message is output,
	 * not directly printed, in order to give formatting 
	 * control to invoking methods.
	 */
	String quickUse(int damage, Fighter target) {
	
		this.spendMana();
		
		return this.getMessage(target.harm(damage), target);
	}
	
	
	/**
	 * Indicates if any instances of the Spell
	 * class on the "allAction" ArrayList are 
	 * marked learned. 
	 * 
	 * @return True if there is at least one Spell
	 * marked learned, False otherwise.
	 */
	static boolean anyLearned() {
		
		for (int a = 0; a < Action.totalActions(); a++) {
			
			Action current = Action.findAction(a);
			
			if ((current instanceof Spell) && current.isLearned()) {
				
				return true;
			} else {}
		}
		
		return false;
	}
}