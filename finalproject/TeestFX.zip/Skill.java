import java.util.ArrayList;

/**
 * A subclass of Action intended to represent "martial manuevers" that use a 
 * specific armament. The static integer "cooldown" represents the Hero
 * being unable to use Skills for a certain number of turns after 
 * the use of another.
 * 
 * @author Kayden Barlow
 */
class Skill extends Action {
	
	/**
	 * Constructor for "permanent" instances 
	 * of the Skill object. Differs from its
	 * parent's constructor only in requiring
	 * that a Gear object is entered in the Stat
	 * parameter.
	 * 
	 * @param name String of the Skill's name.
	 * @param cooldown Integer for the Skill's cooldown. (This is this
	 * Action's "cost" value.)
	 * @param gear Gear object from which the Skill's scaling is derived.
	 * @param message String of the text which will be displayed when the Skill
	 * is used. Placeholders for the implement, target, and damage when used are
	 * [i], [t], and [d] respectively and are replaced by output methods.
	 * @param learned Boolean value indicating if the player has "learned" this
	 * Skill after its creation. If False, the Skill cannot be used regardless 
	 * of other factors.
	 */
	Skill(String name, int cooldown, Gear gear, String message, boolean learned) {
		
		super(name, cooldown, gear, message, learned);
	}
	
	
	/**
	 * Constructor for "incidental" instances
	 * of the Skill object. Differs from its
	 * parent's constructor only in requiring
	 * that a Gear object is entered in the Stat
	 * parameter.
	 * 
	 * @param name String of the Skill's name.
	 * @param id Integer identifying number of the Skill.
	 * @param cooldown Integer for the Skill's cooldown. (This is this
	 * Action's "cost" value.)
	 * @param gear Gear object from which the Skill's scaling is derived.
	 * @param message String of the text which will be displayed when the Skill
	 * is used. Placeholders for the implement, target, and damage when used are
	 * [i], [t], and [d] respectively and are replaced by output methods.
	 */
	Skill(String name, int id, int cooldown, Gear gear, String message) {
		
		super(name, id, cooldown, gear, message);
	}

	
	/**
	 * Overrides the abstract superclass method to give the name
	 * of the "armament" (as specified in the associated Gear
	 * object) used by the Skill, rather than a general Stat name.
	 * 
	 * @return String name of the specific "piece" of Gear used by the Skill.
	 */
	String getImplement() {
	
		return this.getStat().levelName();
	}
	
	/**
	 * If this Skill is marked learned, returns
	 * a String containing the Skill's name and 
	 * its either its Cooldown cost or a message
	 * indicating current cooldown. If it
	 * is not learned, returns "[UNLEARNED]".
	 */
	String menuMessage() {
		
		String message = (this.getName());
		
		if (this.isLearned()) {
			
			message += ("\n(" + this.getImplement() +")\n");
				
				if (getUser().isOnCooldown()) {
					
					message += ("COOLING DOWN");
				} else {
					
					message += ((this.getCost() -1) + "-turn CD");
				}
			
		} else {
			
			message += (" (" + this.getStat().getName() +  ")\n[UNLEARNED]");
		}
		
		return message;
	}
	
	
	/**
	 * Indicates if this Skill can be used.
	 * If Skills are on Cooldown, or if
	 * this instance is unlearned, it is 
	 * not Usable and returns False. Otherwise,
	 * returns True.
	 */
	boolean isUsable() {
		
		return ((!(getUser().isOnCooldown())) && this.isLearned());
	}
	
	
	/**
	 * Increases Cooldown by this Skill's cooldown
	 * parameter. This is equivalent to setting
	 * it to the value in practice, save that if, 
	 * for whatever reason, a Skill with a cooldown
	 * cost is used while Skills are on cooldown,
	 * this will not reduce remaining cooldown to
	 * a lesser value.
	 */
	void setCooldown() {
		
		getUser().setCooldown(this.getCost());	
	}
	
	
	
	
	/**
	 * Method used to provide String descriptions
	 * for exceptions thrown as a result of invalid
	 * Skills. Provides messages in the cases that 
	 * the Skill is on cooldown, that it is unlearned,
	 * and a failsafe in case this method gets called
	 * in any other circumstance. 
	 */
	public String errorMessage() {
		
		if (!this.isLearned()) {
			
			return ("Skill not yet learned.");
		} else if (getUser().isOnCooldown()) {
			
			return ("Skills on cooldown!");
		} else {
			
			return (getName() + " is unusable for some reason...");
		}
	}
	
	
	/**
	 * Consolidates damaging a target with a Skill (using
	 * the integer and Fighter input values), setting its 
	 * Cooldown, and generating its output message 
	 * (also using the inputs). This message is output,
	 * not directly printed, in order to give formatting 
	 * control to invoking methods.
	 */
	String quickUse(int damage, Fighter target) {
		
		this.setCooldown();
		
		return this.getMessage(target.harm(damage), target);
	}
}
