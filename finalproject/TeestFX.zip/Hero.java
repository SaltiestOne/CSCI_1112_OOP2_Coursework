
/**
 * Fighter subclass representing the Hero
 * of Teest. 
 * 
 * The Gauge class is required, as
 * with all Fighter subclasses, as is the Scaler class.
 * 
 * @author Kayden Barlow
 */
public class Hero extends Fighter {

	private int cooldown = 0;
	private Gauge mana = new Gauge(1);
	
	
	/**
	 * Constructor for new instances
	 * of the Hero class. Has a set
	 * name, "Hero", and a level 
	 * parameter based on input. Scales
	 * health and mana parameters on
	 * creation via the Scaler class.
	 * 
	 * @param level Integer initial 
	 * level of this Hero.
	 */
	Hero(int level) {
		
		super("Hero", level, 1);
		setMaxHealth(Scaler.maxHealth(getLevel(), scaleHealth()), true);
		this.mana = new Gauge(Scaler.maxMana(getLevel(), scaleMana()));
	}
	
	
	/**
	 * Returns the integer representing
	 * the number of turns remaining until
	 * this Hero can use another Skill. 
	 * 
	 * @return Integer value of cooldown.
	 */
	int getCooldown() {
		
		return cooldown;
	}
	
	
	/**
	 * Returns a boolean indicating if
	 * cooldown is a positive value, 
	 * and therefor that Skills are on 
	 * cooldown.
	 * 
	 * @return True if cooldown is greater than
	 * zero, False if it is zero (or less, somehow).
	 */
	boolean isOnCooldown() {
		
		if (cooldown <= 0) {
			
			return false;
		} else {
			
			return true;
		}
	}
	
	/**
	 * Sets Cooldown to the specified value.
	 * Cooldown cannot be negative.
	 * 
	 * @param cooldown Integer new Cooldown.
	 */
	void setCooldown(int cooldown) {
		//increases cooldown to a set amount
		if (cooldown >= 0) {
			
			this.cooldown = cooldown;
		} else {
			
			this.cooldown = 0;
		}
	}
	

	
	
	/**
	 * Invokes its sister method to drop
	 * Cooldown by 1. Intended to be invoked at
	 * the end of every turn.
	 */
	public void dropCooldown() {
		
		this.dropCooldown(1);
	}
	
	
	/**
	 * Reduces Cooldown value by the input
	 * amount. Cooldown cannot be negative.
	 * 
	 * @param decrement Integer amount to reduce
	 * Cooldown.
	 */
	void dropCooldown(int decrement) {
		//decreases by a set amount, not to a negative value
		if ((cooldown - decrement) >= 0) {
		
			cooldown -= decrement;
		} else {
			
			cooldown = 0;
		}
	}
	
	
	/**
	 * Returns the value of the Hero's
	 * maximum Mana paramater.
	 * 
	 * @return Integer maximum Mana.
	 */
	int getMaxMana() {
		
		return mana.getMax();
	}
	
	
	/**
	 * Adjusts the maximum Mana
	 * value to the input integer. Also
	 * sets current Mana to the same value.

	 * 
	 * @param maxMana Integer of the new
	 * maximum Mana value.
	 */
	void setMaxMana(int maxMana) {
		
		mana.setMax(maxMana, true);
	}
	

	/**
	 * Returns the integer value of the
	 * Hero's available Mana.
	 * 
	 * @return Integer of available Mana.
	 */
	int getMana() {
		
		return mana.getCurrent();
	}
	
	/**
	 * Sets the currently available Mana
	 * to the input amount. This cannot be
	 * negative, or exceed the maximum Mana 
	 * value.
	 * 
	 * @param mana Integer new Mana value.
	 */
	void setMana(int mana) {
		
		this.mana.setCurrent(mana);
	}
	

	
	/**
	 * Attempts to reduce current Mana by
	 * the input amount. Exception is thrown 
	 * if the input amount exceeds available Mana.
	 * 
	 * @param amount Integer reduction in current Mana.
	 * @return Boolean True if Mana was sufficient and
	 * was spent, False otherwise.
	 */
	boolean spendMana(int amount) {
		
		if (amount > getMana()) {
			
			return false;
		} else {
			
			mana.adjust(-amount);
			
			return true;
		}
	}
	
	
	/**
	 * Increases the current Mana by the 
	 * input amount. Will not exceed the
	 * maximum Mana value.
	 * 
	 * @param amount Integer to be added 
	 * to available Mana.
	 */
	void upMana(int amount) {
		
		mana.adjust(amount);
	}
	
	
	/**
	 * Indicates if current Mana is less
	 * than maximum.
	 * 
	 * @return False if current and maximum
	 * Mana are equal, True otherwise.
	 */
	boolean manaSpent() {
		
		if (!(mana.isFull())) {
			
			return true;
		} else {
			
			return false;
		}
	}
	
	
	/**
	 * Returns a String containing both
	 * current and maximum Mana, intended
	 * for menus and such.
	 * 
	 * @return Available and maximum Mana
	 * values, seperated by a slash.
	 */
	String manaGauge() {
		
		return mana.getGauge();
	}
	
	
	/**
	 * Outputs a message containg this
	 * Hero's name, level, and information
	 * about each of its associated Stat
	 * objects.
	 * 
	 */
	public String statusMessage() {
		
		String result =  (getName() + "'s Level: " + getLevel());
		
		for (int s = 0; s < stats.size(); s++) {
			
			result += ("\n" + stats.get(s).menuMessage(false));
		}
		
		return result;			
	}
	
	
	
	/**
	 * Returns an integer scaled from any 
	 * HealthScale-implementing Stat objects 
	 * associated with this Hero. This
	 * integer is intended to be used to 
	 * set the Hero's maximum Health parameter.
	 * 
	 * @return Integer scaled from 
	 * HealthScale-implementing Stat objects.
	 */
	public int scaleHealth() {
		
		int scaleGetter = 0;
		
		for (int s = 0; s < stats.size(); s++) {
			
			if (stats.get(s) instanceof HealthScale) {
				
				scaleGetter += ((HealthScale)stats.get(s)).healthScale();
			}
		}
		
		return scaleGetter;
	}
	
	
	/**
	 * Returns an integer scaled from any 
	 * ManaScale-implementing Stat objects 
	 * associated with this Hero. This
	 * integer is intended to be used to 
	 * set the Hero's maximum Mana parameter.
	 * 
	 * @return Integer scaled from 
	 * ManaScale-implementing Stat objects.
	 */
	public int scaleMana() {
		
		int scaleGetter = 0;
		
		for (int s = 0; s < stats.size(); s++) {
			
			if (stats.get(s) instanceof ManaScale) {
				
				scaleGetter += ((ManaScale)stats.get(s)).manaScale();
			}
		}
		
		return scaleGetter;
	}
	
	
	/**
	 * Increments the Hero's level,
	 * scales both the health and
	 * mana parameters according to
	 * scaling stats and the Scaler
	 * class, and resets the Skill
	 * cooldown.
	 */
	public void levelUp() {
		
		setLevel(getLevel() + 1);
		setMaxHealth(Scaler.maxHealth(getLevel(), scaleHealth()), true);
		setMaxMana(Scaler.maxMana(getLevel(), scaleMana()));
		setCooldown(0);
	}
}
