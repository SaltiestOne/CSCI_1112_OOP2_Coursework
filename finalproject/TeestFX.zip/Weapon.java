/**
 * Concrete Gear subclass meant to represent some type
 * of sword weilded by a Fighter. Intended to define and 
 * scale certain Skill objects. Implements HealthScale
 * to affect an associated Fighter's Health parameter.
 * As with all Stat subclasses, the level parameter and 
 * the static maxLevel value are facilitated via a Gauge
 * object, and thus the Gauge class is necessary
 * for instantiating any objects of this class.
 * 
 * @author Kayden Barlow
 */
public class Weapon extends Gear {

	
	/**
	 * Constructor for instances of the Weapon
	 * class. Must be assigned to an 
	 * instance of the Fighter class, and will
	 * be added to that Fighter's ArrayList
	 * of stats. The name parameter will be fixed
	 * as "Weapon".
	 * 
	 * @param user Fighter to which the Stat
	 * is assigned.
	 * @param level Integer value of the Stat's
	 * relative power.
	 */
	Weapon(Fighter user, int level) {
		
		super(user, "Weapon", level, new String[] {"Club", "Shortsword", "Longsword", "Katana"});
	}
	
	
	/**
	 * Creates a instance of this object with
	 * a level parameter of zero. As the superclass
	 * constructor automatically adds new Stat objects
	 * to the Fighter's list of stats, this is intended
	 * to be used to quickly add a new, generic Weapon
	 * Gear Stat to the input Fighter.
	 * 
	 * @param user Fighter to receive a new instance
	 * of this object.
	 */
	static void add(Fighter user) {
		
		new Weapon(user, 0);
	}
}