import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

/**
 * Abstract class used to store commonly used
 * formatting objects. These can be called upon
 * by other objects to ensure consistency in style.
 * Currently, stores three color objects as 
 * parameters, a String parameter representing
 * the name of a Font object, and default Font size. 
 * 
 * @author Kayden Barlow
 */
abstract public class Formatter {
	
	private static String font;
	private static int size;
	private static Color mainColor;
	private static Color warnColor;
	private static Color fadeColor;
	
	
	/**
	 * Sets the static value of the "main"
	 * Color parameter.
	 * 
	 * @param mainColor Color to be used for
	 * most nodes.
	 */
	static void setMainColor(Color mainColor) {
		
		Formatter.mainColor = mainColor;
	}
	
	
	/**
	 * Returns the static value of the "main"
	 * Color parameter.
	 * 
	 * @return Color object to be used for most
	 * nodes.
	 */
	static Color getMainColor() {
		
		return Formatter.mainColor;
	}
	
	
	/**
	 * Sets the static value of the "warning"
	 * Color parameter.
	 * 
	 * @param warnColor Color to be used for
	 * nodes inidicating a warning or submaximal value.
	 */
	static void setWarnColor(Color warnColor) {
		
		Formatter.warnColor = warnColor;
	}
	
	
	/**
	 * Returns the static value of the "warning"
	 * Color parameter.
	 * 
	 * @return Color object to be used for
	 * nodes inidicating a warning or submaximal value.
	 */
	static Color getWarnColor() {
		
		return Formatter.warnColor;
	}
	
	
	/**
	 * Sets the static value of the "fade"
	 * Color parameter.
	 * 
	 * @param fadeColor Color to be used for
	 * unavailable nodes or empty information.
	 */
	static void setFadeColor(Color fadeColor) {
		
		Formatter.fadeColor = fadeColor;
	}
	
	
	/**
	 * Returns the static value of the "fade"
	 * Color parameter.
	 * 
	 * @return Color object to be used for
	 * unavailable nodes or empty information.
	 */
	static Color getFadeColor() {
		
		return Formatter.fadeColor;
	}
	
	
	/**
	 * Sets the static name corresponding
	 * to a Font object to be used by formatted
	 * nodes.
	 * 
	 * @param font Name of static Font.
	 */
	static void setFont(String font) {
		
		Formatter.font = font;
	}
	
	
	/**
	 * Sets the default font size for
	 * the Font retrieved by this class.
	 * 
	 * @param size Integer value of the
	 * default Font size.
	 */
	static void setSize(int size) {
		
		Formatter.size = size;
	}
	
	
	/**
	 * Returns the Font object corresponding to
	 * the static String name set to this class,
	 * with a size determined by the input integer.
	 * 
	 * @param size Integer of the Font's size.
	 * @return Font statically set to this class.
	 */
	static Font getFont(int size) {

		return (Font.font((Formatter.font),size));
	}
	
	/**
	 * Returns the Font object corresponding to
	 * the static String name set to this class,
	 * with the default size also determined
	 * statically by this class.
	 * 
	 * @return Font statically set to this class.
	 */
	static Font getFont() {
		
		return getFont(Formatter.size);
	}
	
	/**
	 * Returns the Font object corresponding to
	 * the static String name set to this class,
	 * with the BOLD FontWeight and a size 
	 * determined by the input integer.
	 * 
	 * @param size Integer of the Font's size.
	 * @return Font statically set to this class.
	 */
	static Font getBoldFont(int size) {
		
		return (Font.font((Formatter.font), FontWeight.BOLD, size));
	}
	
	
	/**
	 * Returns the Font object corresponding to
	 * the static String name set to this class,
	 * with the BOLD FontWeight and the default 
	 * size determined statically by this class.
	 * 
	 * @return Font statically set to this class.
	 */
	static Font getBoldFont() {
		
		return getBoldFont(Formatter.size);
	}
	
	
	/**
	 * Returns the Font object corresponding to
	 * the static String name set to this class,
	 * with the ITALIC FontPosture and a size 
	 * determined by the input integer.
	 * 
	 * @param size Integer of the Font's size.
	 * @return Font statically set to this class.
	 */
	static Font getItalicFont(int size) {
		
		return (Font.font((Formatter.font), FontPosture.ITALIC, size));
	}
	
	
	/**
	 * Returns the Font object corresponding to
	 * the static String name set to this class,
	 * with the ITALIC FontPosture and the default 
	 * size determined statically by this class.
	 * 
	 * @return Font statically set to this class.
	 */
	static Font getItalicFont() {
		
		return getItalicFont(Formatter.size);
	}
	
}
