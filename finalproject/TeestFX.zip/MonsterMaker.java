import java.util.Random;

/**
 * Abstract class containing static methods
 * used to build a Monster object from a list
 * of pre-written Strings, scaling its health
 * and level from the Scaler class.
 * 
 * @author Kayden Barlow
 */
abstract class MonsterMaker {

	private static String[][] monsters;
	public static boolean set = false;

	/**
	 * Outputs a Monster object randomly
	 * determined from a static list of
	 * String array constructors. The potential
	 * output varies based on the round
	 * parameter of the Scaler class, 
	 * with its level and health scaling
	 * from the same parameter. 
	 * 
	 * @return Monster object created at
	 * random.
	 */
	public static Monster make() {
		
		set();
		
		int round = Scaler.getRound();

		String[] flavor = monsters[Math.min(monsters.length,
			(new Random().nextInt((4 + (int)(1.2 * round))) + (round - 1)))];

		return new Monster(flavor, round, ((14 * round) + 1));
	}
	
	
	/**
	 * Assigns the static list of potential
	 * Monster constructor String arrays with
	 * a pre-written list. To prevent redundant
	 * tasks, checks a static boolean before
	 * doing this, which is set True the first 
	 * time this method is invoked. 
	 */
	public static void set() {
		
		if (!set) {
			
			monsters = new String [][] { 
				{"Rat", "bites", "chomps", 
					"Not even a big one. It's, like, a foot from nose to tail.",
					"It's only trouble because it's so hard to hit."}, 
				{"Tree Snake", "bites", "lunges at", 
					"Mostly eats small animals. Lays on treetops for warmth.",
					"Attacks in self-defense if knocked off the branches."}, 
				{"Half-Skeleton", "tackles", "strangles", 
					"Shambles around missing an arm, its feet, and some ribs.",
					"Crawls on 'all threes' and throws itself at threats."},
				{"Lone Wolf", "bites", "pounces on", 
					"Usually, the lone wolves are that way for a reason.",
					"This one MIGHT just be misunderstood. But I doubt it."},
				{"Baby Chimera", "rams into", "pins", 
					"Chimeras born in the wild start off relatively weak.",
					"Coordinating all their different parts takes practice."},
				{"Wolfrat", "bites", "gouges",
					"Despite the name, they're a carnivorous cousin of rabbits.",
					"But a layman could assume them to be wolf-rat hybrids."},
				{"Poacher", "shoots at", "entraps",
					"'Poacher' is used euphamistically.",
					"Illegal hunting is a lesser crime than others."},
				{"Dozentalon", "scrapes", "pounces on",
					"Bird of prey with large wings and two pairs of clawed limbs.",
					"A famous poem asks, 'Be a dragon, or a gryphon, that bird?'"},
				{"Ice-Mote", "chills", "freezes",
					"Is it an Air or Water Elemental? Both? Neither?",
					"Many arcanologists have lost friendships over this debate."},
				{"Female Bandit", "chops", "sacks",
					"Has many cheap romance novels hidden under her loot stash.",
					"A hostage nobleman falls for his captor in most of them."},
				{"Green Slime", "splashes", "corrodes",
					"Orcs love these, and eat them raw like in the stories.",
					"Half-orcs hate these, because of stereotypes."},
				{"Catalin Daerg", "stabs", "runs through",
					"This fae warrior appears as a green knight with spears for arms.",
					"Having no mouth, it's easily the most trustworthy type of fairy."},
				{"Refuse Golem", "tosses", "lays waste to",
					"One can really get their mana's worth out of one of these.",
					"They're not only cheaper than other golems, but scarier too."},
				{"Earth Angel", "dusts", "buries",
					"A lizard that hosts special Earth Elementals on its skin.",
					"These envelop the creature in a mass of soil, sand, or clay."},
				{"Haunted Blade", "slashes at", "lacerates", 
					"A worn, discarded sword possessed by a resentful spirit.",
					"Perhaps they, too, felt like an unwanted weapon."},
				{"Edge-Lord", "bleeds", "scars", 
					"Some are mockingly called \"Lords\" of the \"Edge\" of society.",
					"Most are people who traded their morals for power of some kind."},
				{"Blue Wyvern", "snatches", "chomps",
					"This subspecies's breath \"weapon\" isn't harmful; it regulates heat.",
					"This lets it survive in more enviornments than any of its cousins."},
				{"Swordist", "counters", "lunges at",
					"A catch-all term for proficient users of a sword and shield.",
					"A mercenary, bandit, guard... whichever happens to be fighting you."},
				{"Paladin", "shield-bashes", "casts Bolt on",
					"One who uses a shield and magic to defend... something.",
					"Sanctioned holy warriors are called this only as an insult."},
				{"Battle-Mage", "strikes", "Mana-Bursts",
					"Student of both martial and arcane arts, out to prove something.",
					"Channels various spells through an overdesigned two-handed weapon."},
				{"False Phoenix", "singes", "roasts",
					"A bird that creates fire to assist with flight, hunting, and defense.",
					"Known by other names in places without a concept of a \"phoenix.\""},
				{"Wheelchair Drake", "rolls into", "yuhs",
					"Congrats. You're clearly strong enough and lucky enough.",
					"You've earned the right to fight the token joke enemy."},
				{"Hero's Shadow", "mimics", "nullifies",
					"None can deafeat their own shadow, only hold it back.",
					"And sometimes, it becomes more popular than its original."}};
					
				set = true;
				
		} else {}
	}
}
