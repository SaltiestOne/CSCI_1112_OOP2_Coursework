import java.util.Random;

/**
 * Subclass of Fighter representing the enemies that the
 * Hero will fight. Requires a String array for its constructor,
 * which includes its name, attack verbs, and a flavorful decription.
 * (How "monstrous" some of these enemies are will be left for the 
 * reader's ideology to determine). The Gauge class is required, as
 * with all Fighter subclasses, as is the Scaler class.
 * 
 * @author Kayden Barlow
 */
class Monster extends Fighter {
	
	private String[] flavor;
	private int damage;
	private boolean stunned = false;
	private boolean critical = false;
	
	/**
	 * Constructor for instances of the Monster
	 * class. This includes a String array for 
	 * the name, attack and critical verbs, and 
	 * flavor text of the Monster, as well it's 
	 * level and initial health. Automatically
	 * prepares the Monster's damage and critical
	 * parameters on creation.
	 * 
	 * @param flavor A String array at least 5 Strings long,
	 * containing, in order: [0] Name, [1] Basic Attack verb,
	 * [2] Critical hit verb, and [3]/[4] two lines of
	 * flavor text. 
	 * @param level Integer value of the 
	 * Monster's relative power.
	 * @param maxHealth Integer value of the 
	 * Monster's maximum health points.
	 */
	Monster(String[] flavor, int level, int maxHealth) {
		
		super(flavor[0], level, maxHealth);
		
		this.flavor = flavor;
		
		prepare();
	}
	
	
	/**
	 * Returns a String containing the
	 * Monster's name, level, and flavor
	 * text.
	 * 
	 * @return String containing end-user
	 * information about the Monster.
	 */
	public String statusMessage() {
		
		return (getName() + "'s Level: " + getLevel() + "\n" + flavorText());
	}
	
	
	/**
	 * Outputs the Monster's flavor text.
	 * 
	 * @return String containing two lines of flavor text.
	 */
	public String flavorText() {
		
		return (flavor[3] + "\n" + flavor[4] + "\n");
	}
	
	
	/**
	 * Returns the current Damage value
	 * for this Monster.
	 * 
	 * @return Integer damage parameter.
	 */
	int getDamage() {
		
		return this.damage;
	}
	
	
	/**
	 * Sets the integer damage parameter to an int value 
	 * to a random number scaling based on the monster's level. 
	 * This number has a floor of one, and a ceiling 
	 * which scales faster than the player's normal damage
	 * number should. This is to create a more "random"
	 * damage amount for enemies. This method also randomly 
	 * determines if the monster currently has its critical
	 * parameter set to True, with the percentage chance equaling
	 * eight plus twice its level.
	 * 
	 */
	void prepare() {
		
		this.stunned = false;
		
		setDamage(Scaler.monsterDamage(getLevel()));
		
		if ((new Random().nextInt(100)) < (8 + (2 * getLevel()))) {
			critical = true;
		} else {}
	}
	
	
	/**
	 * Sets the Monster's damage parameter to the
	 * input value. Damage cannot be negative.
	 * If it is set to zero, Monster is stunned,
	 * and damage is recalculated as if normal 
	 * (in case a critical overrides the stun).
	 * 
	 * @param damage Integer value of the
	 * Monster's new damage parameter.
	 */
	void setDamage(int damage) {
		
		if (damage <= 0) {
			
			this.damage = Scaler.monsterDamage();
			
			this.stun();
		} else {
		
			this.damage = damage;
		}
	}
	
	
	/**
	 * Causes the monster to be stunned, negating one
	 * turn: either the monster will be unable to take
	 * its next normal attack, or it will "downgrade" a 
	 * critical hit to a normal attack.
	 */
	void stun() {
		
		this.stunned = true;
	}
	
	
	/**
	 * The Monster's action. Currently, monsters can
	 * only attack, attack critically, or be stunned.
	 * The procedures for each are contained in this
	 * method, with the scenario executed determined
	 * by the stunned and critical parameters. Outputs
	 * the message appropriate to the Monster's action,
	 * but the effects will happen even if this String
	 * is unused. Note that the stunned and critical
	 * parameters are not reset by this method, on the
	 * assumption that the prepare() method will be 
	 * invoked before the next invocation of this method.
	 * 
	 * @param target Fighter targeted by the damage of
	 * the Monster's attack.
	 * @return String of the message describing the 
	 * Monster's action.
	 */
	String action(Fighter target) {
		
		if (stunned && (!critical)) {
		
			return ("\nThe " + this.getName() + " is unable to harm the " + target.getName() + ".\n\n");	
		} else if (critical && (!stunned)) {

			return ("\nCritical hit! The " + this.getName() + "\n " + this.flavor[2]
			+ " you for " + target.harm(2 * this.damage) + " damage.\n");
		} else {
			//applies if neither stunned nor critical, OR if both are true; critical "overrides" stun.
		
			return ("\nThe " + this.getName() + " " + this.flavor[1] + " you,\n and you receive "
					+ target.harm(this.damage) + " damage.\n");
		}
	}
}