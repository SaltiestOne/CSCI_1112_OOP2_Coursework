
import java.util.ArrayList;
import java.util.Random;


/**
 * Abstract classs representing a some kind of combat 
 * participant. Makes use of the Gauge class to
 * facilitate the "health" parameter, as well as the 
 * Scaler class for some methods. Those classes will 
 * need to be present to instantiate a subclass of 
 * Fighter or use those methods, respectively.
 * 
 * @author Kayden Barlow
 */
abstract class Fighter {
	
	private String name;
	private int level;
	private Gauge health;
	protected ArrayList<Stat> stats = new ArrayList<Stat>();
	
	/**
	 * Constructor for instances of a Fighter
	 * subclass. On construction, the integer
	 * health parameter will be equal to
	 * the maximum health parameter.
	 * 
	 * @param name String name of the Fighter.
	 * @param level Integer value of the 
	 * Fighter's relative power.
	 * @param maxHealth Integer value of the 
	 * Fighter's maximum health points.
	 */
	Fighter(String name, int level, int health) {
		
		this.name = name;
		this.level = level;
		this.health = new Gauge(health);
	}
	
	
	/**
	 * No-arg constructor for instances of a
	 * Fighter subclass. Sets the name parameter
	 * to "Noone", level to 0, and 
	 * maximum/current health to 1.
	 * 
	 * 
	 */
	Fighter() {
		
		this("Noone", 0, 1);
	}
	
	
	/**
	 * Returns the String of the
	 * Fighter's name parameter.
	 * 
	 * @return String name of the Fighter.
	 */
	public String getName() {
		
		return name;
	}
	
	
	/**
	 * Returns the integer value of the 
	 * Fighter's level parameter.
	 * 
	 * @return Level of the Fighter.
	 */
	public int getLevel() {
		
		return level;
	}
	
	
	/**
	 * Sets the Fighter's level to the 
	 * input integer. Level cannot
	 * be negative.
	 * 
	 * @param level Integer value of 
	 * new level.
	 */
	public void setLevel(int level) {
		
		if (level <= 0) {
			
			level = 0;
		} else {
			
			this.level = level;
		}
	}
	
	
	/**
	 * Returns the integer value of the
	 * Fighter's maximum health parameter.
	 * 
	 * @return Integer value of the 
	 * Fighter's maximum health.
	 */
	public int getMaxHealth() {
		
		return health.getMax();
	}
	
	
	/**
	 * Adjusts the Fighter's maximum
	 * health parameter to the input amount.
	 * Maximum health cannot be negative.
	 * If current health exceeds the new value,
	 * or if the boolean input is set to "True"
	 * (the latter is intended as "full heal"
	 * as part of a level-up), then health
	 * is set equal to the value of maximum
	 * health.
	 * 
	 * @param maxHealth Integer value of the
	 * new maximum health.
	 * @param heal If True, health parameter
	 * is made equal to maximum.
	 */
	public void setMaxHealth(int maxHealth, boolean heal) {
		
		health.setMax(maxHealth, heal);
	}
	
	
	/**
	 * Returns the integer value of the
	 * Fighter's current health parameter.
	 * 
	 * @return Integer value of the Fighter's
	 * health.
	 */
	public int getHealth() {
		
		return health.getCurrent();
	}

	
	/**
	 * Adjusts the Fighter's health parameter
	 * to the input integer. Health cannot
	 * be negative or exceed the Fighter's 
	 * maximum health parameter.
	 * 
	 * @param health Integer value of the
	 * Fighter's new health parameter.
	 */
	public void setHealth(int health) {
		
		this.health.setCurrent(health);
	}
	
	
	
	/**
	 * Adds the input Stat object to
	 * this Fighter's "stats" ArrayList.
	 * By default, all Stat subclasses 
	 * invoke this on thier constructing
	 * Fighter during their instantiation. 
	 * 
	 * @param stat Stat object to be
	 * associated with this Fighter.
	 */
	public void addStat(Stat stat) {
		
		this.stats.add(stat);
	}
	
	
	/**
	 * Returns the full "stats" ArrayList
	 * containing all Stat objects 
	 * associated with this Fighter. 
	 * 
	 * @return ArrayList<Stat> listing
	 * all Stat objects associated with
	 * invoking Fighter.
	 */
	public ArrayList<Stat> getStats() {
		
		return this.stats;
	}
	
	
	/**
	 * Returns one of this Fighter's 
	 * associated Stat objects. Input 
	 * String is the name of the 
	 * desired Stat object, which in
	 * most cases will be the name 
	 * of the Class of the Stat.
	 * Throws an exception if no
	 * Stat with the input name is
	 * found. 
	 * 
	 * @param statName String of the
	 * name of the desired Stat.
	 * @return Stat object matching 
	 * the input name String.
	 */
	public Stat getStat(String statName) {
		
		for (int s = 0; s < stats.size(); s++) {
			
			if (stats.get(s).getName().equals(statName)) {
				
				return stats.get(s);
			} else {}
		}
		
		throw new NullPointerException("Stat not found!");
	}
	
	
	/**
	 * Indicates if all of the Fighter's
	 * associated Stat objects are at 
	 * their maximum level. 
	 * 
	 * @return True if all Stat objects are
	 * at maximum level, False otherwise.
	 */
	public boolean statMax() {
		
		for (int s = 0; s < stats.size(); s++) {
			
			if (!stats.get(s).isAtMax()) {
				
				return false;
			} else {}
		}
		
		return true;
	}
	
	/**
	 * Returns a String displaying 
	 * max and current health.
	 * 
	 * @return A String with the current and max health,
	 * seperated by a slash.
	 */
	public String healthGauge() {
		
		return health.getGauge();
	}
	
	
	
	/**
	 * Indicates if the health parameter is 
	 * less than its maximum value. 
	 * 
	 * @return False if the health parameter
	 * is at its maximum, True otherwise.
	 */
	public boolean isDamaged() {
		
		return (!(health.isFull()));
	}
	
	
	/**
	 * Indicates if the health parameter
	 * is equal to zero.
	 * 
	 * @return True if the health parameter
	 * is equal to zero, False otherwise.
	 */
	public boolean isDead() {
		
		if (health.getCurrent() <= 0) {
			
			return true;
		} else {
			
			return false;
		}
	}
	
	
	/**
	 * Returns a random integer generated
	 * according to the input integer, intended 
	 * to be used for Action scaling. The
	 * "floor" of the output, equal to the input, 
	 * is the mimimum output value. The 
	 * "fluctuation" value, adds one-fourth
	 * the input (rounded down) to the set
	 * number 6 to determine the range of
	 * the random numbers possible. Fluctuation
	 * is reduced in this way in order to slowly 
	 * increase the range of possible values
	 * as scalers increase. This method is 
	 * used instead of its two-arg sister
	 * in cases where the floor and 
	 * fluctuation are equal.
	 * 
	 * @param mod Integer minimum of the output.
	 * @return Random integer, scaled according 
	 * to above formula.
	 *
	static int damage(int mod) {
		//yes im making this static to make some methods easier, this wouldn't work if there were more than one player
		return Fighter.damage(mod,mod);
	}*/
	
	
	/**
	 * Returns a random integer generated
	 * according to two factors, intended to
	 * be used for Action scaling. The first,
	 * the "floor" integer, is the mimimum
	 * output value. The second, the
	 * "fluctuation" value, adds one-fourth
	 * of itself (rounded down) to the set
	 * number 6 to determine the range of
	 * the random numbers possible. Fluctuation 
	 * is reduced in this way in order to slowly 
	 * increase the range of possible values
	 * as scalers increase. For this reason,
	 * the fluctuation value should just be 
	 * the Hero's level in most cases.
	 * 
	 * @param floor Integer minimum output.
	 * @param fluctuation Integer used to adjust
	 * range of outputs.
	 * @return Random integer, scaled according 
	 * to above formula.
	 *
	static int damage(int floor, int fluctuation) {
		
		return ((new Random().nextInt(6 + (int)(fluctuation * 0.25))) + floor);
	}*/
	
	
	
	
	/**
	 * Reduces this Fighter's health parameter
	 * by the input amount. Health cannot be 
	 * negative. Output is identical to the input,
	 * intended for consolidation of methods that 
	 * display (or otherwise use the damage number)
	 * with the effect of this method. If only the
	 * effect and not the output are desired, 
	 * the method can be used as if it were void.
	 * 
	 * @param damage Integer reduction to Fighter's
	 * health parameter.
	 * @return Integer identical to input.
	 */
	int harm(int damage) {
		
		health.adjust(-damage);
		
		return damage;
	}
	
	
	/**
	 * Increases this Fighter's health parameter
	 * by the input amount. Health cannot go above
	 * the Fighter's maximum health parameter. 
	 * Output is identical to the input,
	 * intended for consolidation of methods that 
	 * display (or otherwise use the cure number)
	 * with the effect of this method. If only the
	 * effect and not the output are desired, 
	 * the method can be used as if it were void.
	 * 
	 * @param damage Integer increase to Fighter's
	 * health parameter.
	 * @return Integer identical to input.
	 */
	int heal(int cure) {
		
		health.adjust(cure);
		
		return cure;
	}
	
	/**
	 * Abstract method outputting a 
	 * String containing information
	 * about this particular Fighter,
	 * intended to be displayed to players.
	 * Could potentially include items
	 * such as the Fighter's name, level,
	 * Stat objects, or flavor text. 
	 * 
	 * @return String containing end-user
	 * information about this Fighter.
	 */
	abstract public String statusMessage();
}