/**
 * Class defining two integers, a positive "current"
 * parameter and a "max" parameter that "current" cannot
 * exceed. Both can be manipulated and adjusted, but the
 * "current" parameter is always bound between zero and 
 * the "max" parameter, inclusive.
 * 
 * @author Kayden Barlow
 */
public class Gauge {

	private int current;
	private int max;
	
	
	/**
	 * Constructor for instances of the 
	 * Gauge class for which the "current"
	 * and "max" parameters will be the 
	 * same on creation, i.e., it "starts at
	 * max."
	 * 
	 * @param max Integer of the initial maximum
	 * value of the Gauge.
	 */
	Gauge(int max) {
		
		this.max = max;
		
		maximize();
	}
	
	
	/**
	 * Constructor for instances of the 
	 * Gauge class for which the "current"
	 * and "max" parameters will be different
	 * on creaction. The "current" parameter
	 * must still fall within its bounds.
	 * 
	 * @param current Integer of the initial 
	 * "current" parameter.
	 * @param max Integer of the initial "max"
	 * parameter.
	 */
	Gauge(int current, int max) {
		
		this.max = max;
		
		setCurrent(current);
	}
	
	
	/**
	 * Sets the "current" parameter for this
	 * Gauge. If the input value is above the 
	 * "max" parameter or below zero, the 
	 * "current" parameter will instead be set
	 * to that respective value.
	 * 
	 * @param current Integer of the new current
	 * parameter.
	 */
	public void setCurrent(int current) {
		
		if (current > this.max) {
			
			this.maximize();
		} else if (current < 0) {
			
			this.current = 0;
		} else {
			
			this.current = current;
		}
	}
	
	/**
	 * Returns the value of the "current"
	 * parameter.
	 * 
	 * @return Integer of the bounded "current"
	 * parameter.
	 */
	public int getCurrent() {
		
		return this.current;
	}
	
	
	/**
	 * Sets the "max" parameter for
	 * this Gauge. If this brings the
	 * value below that of the "current"
	 * parameter, "current" is adjusted
	 * to be equal to "max", but the 
	 * "current" parameter is unchanged
	 * otherwise.
	 * 
	 * @param max Integer of the new "max"
	 * parameter.
	 */
	public void setMax(int max) {
		
		setMax(max, false);
	}
	
	
	/**
	 * Sets the "max" parameter for
	 * this Gauge. If the "maximize" 
	 * input is True, of if the new "max"
	 * parameter is less than the "current"
	 * parameter, "current" is adjusted
	 * to be equal to "max". 
	 * 
	 * @param max Integer of the new "max"
	 * parameter.
	 * @param maximize Boolean determining
	 * if "current" parameter is maximized.
	 */
	public void setMax(int max, boolean maximize) {

		if (this.current > max) {
			//just to ensure the current value is NEVER, EVER above max, even for a split-second.
			setCurrent(max);
		} else {}
			
		this.max = max;	
		
		if (maximize && (!isFull())) {
			//yes, even if it means i have to write it like this.
			maximize();
		}
	}
	
	
	/**
	 * Returns the value of the maximum 
	 * allowed value of the "current" parameter.
	 * 
	 * @return Integer value of the "max" 
	 * parameter.
	 */
	public int getMax() {
		
		return this.max;
	}

	
	/**
	 * Sets the "current" parameter to be
	 * equal to the "max" parameter. 
	 */
	public void maximize() {
		
		this.current = this.max;
	}
	
	
	/**
	 * Adds the input value to the current 
	 * "current" parameter. Input can be negative
	 * to allow for subtraction of the value.
	 * As always, the new "current" parameter
	 * can not be less than zero or greater than
	 * the "max" value.
	 * 
	 * @param amount Integer adjustment to the 
	 * "current" parameter.
	 */
	public void adjust(int amount) {
		
		this.setCurrent(this.current + amount);
	}
	
	
	/**
	 * Indicates if the "current" parameter is equal
	 * to the maximum allowed value.
	 * 
	 * @return True if the "current" parameter is 
	 * equal to the "max" parameter, False otherwise.
	 */
	public boolean isFull() {
		
		if (this.current == this.max) {
			
			return true;
		} else {
			
			return false;
		}
	}
	
	
	/**
	 * Returns a String with both parameters,
	 * seperated by a slash.
	 * 
	 * @return String of the "current" and "max"
	 * parameters, seperated by a slash.
	 */
	public String getGauge() {
		
		return (this.current + "/" + this.max);
	}
}
