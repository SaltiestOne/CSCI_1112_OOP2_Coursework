/**
 * Abstract class representing some quantifiable, if intangible,
 * aspect of a Fighter. Used for scaling Actions, as
 * well as various parameters and variables within the 
 * Main. Defines a static "maxLevel" parameter representing
 * the highest value that any subclass's level parameter
 * can reach. Level and maxLevel are facilitated via a Gauge
 * object within subclasses, and thus the Gauge class is necessary
 * for instantiating any subclasses.
 * 
 * @author Kayden Barlow
 */
abstract class Stat {
	
	private Fighter user;
	private String name;
	private Gauge level;
	private static int maxLevel = 5;
	
	/**
	 * Constructor for instances of the Stat
	 * class. Must be assigned to an 
	 * instance of the Fighter class, and will
	 * be added to that Fighter's ArrayList
	 * of stats. Objects of this class's subclasses
	 * are necessary to define instances of
	 * Action subclasses. The name paramter will often 
	 * be fixed within a particular subclass.
	 * 
	 * @param user Fighter to which the Stat
	 * is assigned.
	 * @param name String name of the Stat.
	 * @param level Integer value of the Stat's
	 * relative power.
	 */
	Stat(Fighter user, String name, int level) {
		
		this.user = user;
		this.name = name;
		this.level = new Gauge(level, Stat.maxLevel);
		this.user.addStat(this);
	}
	

	/**
	 * Returns the reference for the instance
	 * of the Fighter class to which the Stat
	 * is assigned.
	 * 
	 * @return Fighter user of the Stat.
	 */
	Fighter getUser() {
		
		return this.user;
	}
	
	
	/**
	 * Returns the name of the Stat.
	 * 
	 * @return String Stat name.
	 */
	String getName() {
		
		return name;
	}
	
	
	/**
	 * Returns the "level" parameter
	 * of the Stat.
	 * 
	 * @return Integer level value.
	 */
	int getLevel() {
		
		return level.getCurrent();
	}
	
	
	/**
	 * Returns a String of the current
	 * and maximum level parameters. If 
	 * these two values are equal, instead
	 * returns "MAX".
	 * 
	 * @return String indicating the current
	 * level parameter relative to its maximum value.
	 */
	String getLevelString() {
		
		if (this.isAtMax()) {
			
			return ("MAX");
		} else {
			
			return level.getGauge();
		}
	}
	
	
	/**
	 * Outputs a message containing the Strings of 
	 * the name parameter and the levelString method.
	 * The Boolean "enter" input determines
	 * if the output message is formatted with a line break 
	 * or a simple space between the name and level data. 
	 * 
	 * @param enter Boolean representing if the output
	 * String should have a line break.
	 * 
	 * @return String containing information about the Stat's
	 * name and level.
	 */
	String menuMessage(boolean enter) {
		
		if (enter) {
		
			return (this.getName() + "\n(Level " + this.getLevelString() +")");
		} else {
			
			return (this.getName() + " (Level " + this.getLevelString() +")");
		}
	}

	
	/**
	 * Returns a "scaled" integer value
	 * derived from the level parameter of 
	 * both the Stat and its assigned Fighter, 
	 * equal to twice the level of the Stat
	 * plus the level of the user. This is 
	 * a deliberate choice, to make Stat investments
	 * matter more than simple level-ups.
	 * 
	 * @return Integer scaled from the user's level
	 * parameter and this object's level paramter.
	 */
	int getModdedLevel() {
		
		return ((this.getLevel() * 2) + user.getLevel());
	}
	
	
	/**
	 * Sets the level parameter to the 
	 * input integer value. Level cannot
	 * be negative or above the static 
	 * maxLevel parameter, as faciliated
	 * by the Gauge class.
	 * 
	 * @param level Integer new value of
	 * level parameter.
	 */
	void setLevel(int level) {
		
		this.level.setCurrent(level);
	}
	
	
	/**
	 * Increments the level parameter. Methods
	 * within the facilitating Gauge class
	 * ensure that this does not exceed the 
	 * static maxLevel parameter.
	 */
	void upLevel()	{
		
		this.setLevel(this.getLevel() + 1);
	}
	
	
	/**
	 * Indicates if the Stat subclass's 
	 * level paramter has reached the 
	 * maximum allowed.
	 * 
	 * @return True if level is equal to
	 * its maximum value, False otherwise.
	 */
	boolean isAtMax() {
		
		return (level.isFull());
	}
	
	
	/**
	 * Returns the value of maximum value
	 * of any subclass's level parameter.
	 * 
	 * @return Integer of the value of the
	 * static maxLevel parameter.
	 */
	static int getMaxLevel() {
		
		return Stat.maxLevel;
	}
	
	
	/**
	 * Returns a String containing information
	 * about the relative power of the 
	 * Stat. As the exact formatting will depend
	 * on the subclass, it is left abstract. Will
	 * often call for the getLevelString or getLevel
	 * methods.
	 *  
	 * @return String describing the object according
	 * to its level parameter.
	 */
	abstract String levelName();
}
