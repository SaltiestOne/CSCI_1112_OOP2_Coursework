import java.util.ArrayList;
import java.util.Random;

/**
 * An abstract class for the various Actions
 * that the Hero can perform. The specifics,
 * including resource costs, are left for 
 * concrete subclasses to define.
 * 
 * @author Kayden Barlow
 */
abstract class Action {
	
	static Monster target;
	private String name;
	private int id;
	private boolean learned = false;
	private String message;
	private int cost;
	private Stat stat;
	private static ArrayList<Action> allActions = new ArrayList<Action>();
	
	
	/**
	 * The constructor for any concrete subclass instances
	 * of the abstract Action class which will be 
	 * added to the static ArrayList containing
	 * "all" Actions (referred to as "permanent" Actions).
	 * If this constructor is invoked instead of its sister, 
	 * the resulting Action's ID value will be equal to its 
	 * position-plus-one in said ArrayList.
	 * 
	 * @param name String of the Action's name.
	 * @param cost Integer for the Action's resources cost, used 
	 * and invoked differently according to its concrete type.
	 * @param stat The Stat object from which the Action's scaling is derived.
	 * @param message String of the text which will be displayed when the Action
	 * is used. Placeholders for the implement, target, and damage when used are
	 * [i], [t], and [d] respectively and are replaced by output methods.
	 * @param learned Boolean value indicating if the player has "learned" this
	 * skill after its creation. If False, the Action cannot be used regardless 
	 * of other factors.
	 */
	Action (String name, int cost, Stat stat, String message, boolean learned) {
		
		this.name = name;
		this.cost = cost;
		this.stat = stat;
		this.message = message;
		this.learned = learned;
		allActions.add(this);
		this.id = (allActions.indexOf(this) + 1);
	}
	
	
	/**
	 * The constructor for any concrete subclass instances
	 * of the abstract Action class which will NOT be 
	 * added to the static ArrayList containing
	 * "all" Actions. This is intended for "incidental"
	 * subclass instances, or for use in subclasses whose
	 * instances should not be added to the list. If this 
	 * constructor is invoked instead of its sister, an 
	 * id value must be specified, and the action is 
	 * learned by default.
	 * 
	 * @param name String of the Action's name.
	 * @param id Integer identifying number of the Action.
	 * @param cost Integer for the Action's resources cost, used 
	 * and invoked differently according to its concrete type.
	 * @param stat The Stat object from which the Action's scaling is derived.
	 * @param message String of the text which will be displayed when the Action
	 * is used. Placeholders for the implement, target, and damage when used are
	 * [i], [t], and [d] respectively and are replaced by output methods.
	 */
	Action (String name, int id, int cost, Stat stat, String message) {
		
		this.name = name;
		this.id = id;
		this.cost = cost;
		this.stat = stat;
		this.message = message;
		this.learned = true;
	}
	
	
	/**
	 * Returns the Action's name parameter.
	 * 
	 * @return String of the Action's name.
	 */
	String getName() {
		
		return name;
	}
	
	
	/**
	 * Returns the "implement," or variable
	 * means by which the skill is "used." Gives
	 * the name of the Stat tied to the Action,
	 * but is itended to be overwritten in subclasses
	 * requiring Gear Stats to give the name of
	 * the specific "piece" of equipment used.
	 * 
	 * @return String of the "thing" used by the Action.
	 */
	String getImplement() {
		
		return this.stat.getName();
	}
	
	
	/**
	 * Gives the ID number of the Action.
	 * For "permanent" Actions, this is determined by its
	 * place on the "allActions" ArrayList. For "incidental"
	 * Actions, ID is set by its constructor. ID numbers 
	 * can be inspected by invoking methods to create that 
	 * Action's distinct effects.
	 * 
	 * @return Integer representing the Action's ID number.
	 */
	int getId() {
		
		return id;
	}
	
	
	/**
	 * Returns the Action's resource cost. How this is used
	 * is intended to be defined by subclasses.
	 * 
	 * @return Integer value of the Action's resource cost.
	 */
	int getCost() {
		
		return cost;
	}
	
	
	/**
	 * First of the output message methods. Replaces any instances of
	 * "[i]" with the name of the Action's implement. Only intended for
	 * use in Actions without a target or damage numbers. Invoked by 
	 * the other output message methods.
	 * 
	 * @return String of the Action's use message, formatted with implement name.
	 */
	String getMessage()	{
		
		return message.replace("[i]",this.getImplement());
	}
	
	
	/**
	 * Second of the output message methods. Invokes the first to replace
	 * "[i]" with implement names, and additionally replaces "[d]"
	 * with the imput damage integer (formatted to a String). Does not require
	 * a target. Invoked by the third output message method.
	 * 
	 * @param damage Integer represting the damage (or other contextual
	 * value) displayed in the message.
	 * @return String of the Action's use message, formatted with
	 * implement name and damage number.
	 */
	String getMessage(int damage) {
		
		return this.getMessage().replace("[d]",new Integer(damage).toString());
	}
	
	
	/**
	 * Third of the output message methods. Invokes the second method (and 
	 * thereby the first as well) to replace "[i]" with the implement
	 * name and "[d]" with the damage number. Replaces "[t]" with the name of 
	 * target of the Action.
	 * 
	 * @param damage Integer represting the damage (or other contextual
	 * value) displayed in the message.
	 * @param target Fighter which will be targeted by the Action.
	 * @return String of the Action's use message, formatted with
	 * implement name, damage number, and target's name.
	 */
	String getMessage(int damage, Fighter target) {
		//replaces a substring in the message with the target of the Action
		return this.getMessage(damage).replace("[t]",target.getName());
	}
	
	
	/**
	 * Indicates if the Action has been learned.
	 * 
	 * @return True if the Action is learned, False if not.
	 */
	boolean isLearned() {
		
		return learned;
	}
	
	
	/**
	 * Sets the Action's "learned" value to True,
	 * indicating that the player has gained the
	 * ability to use it.
	 * 
	 */
	void learn() {
		
		this.learned = true;
	}
	
	
	/**
	 * Sets the Action's "learned" value to False,
	 * removing the player's ability to use it. I
	 * have no plans to use this, but hey, futureproofing.
	 * 
	 */
	void unlearn() {
		
		this.learned = false;
	}
	
	/**
	 * Returns the reference to the Action's 
	 * associated Stat object. Only returns the 
	 * reference, further parameters and methods
	 * must be invoked afterwards.
	 * 
	 * @return Reference of the Stat object 
	 * associated with this Action.
	 */
	Stat getStat() {
		
		return this.stat;
	}
	
	
	/**
	 * Returns the reference to the user of the
	 * Stat object associated with this skill, which
	 * is therefore also the "user" of the skill.
	 * Useful as a shortcut for Actions that affect
	 * their user directly. This object is cast to
	 * the Hero class because reasons
	 * 
	 * @return Reference of the Fighter object (casted
	 * to a Hero object) associated with the Stat 
	 * object associated with this Action.
	 */
	Hero getUser() {
		
		return (Hero)this.stat.getUser();
	}
	
	/**
	 * Sets the static Target parameter
	 * to the input Monster object.
	 * 
	 * @param target Monster to be targeted
	 * by Actions.
	 */
	static void setTarget(Monster target) {
		
		Action.target = target;
	}
	
	
	/**
	 * Returns the static Target parameter,
	 * representing the Monster to be targeted
	 * by Actions.
	 * 
	 * @return Monster to be targeted by Actions.
	 */
	static Monster getTarget() {
		
		return Action.target;
	}
	
	
	/**
	 * Returns the full ArrayList
	 * of all Actions created through
	 * the first Action constructor.
	 * 
	 * @return ArrayList containing all
	 * "permanent" Actions.
	 */
	static ArrayList<Action> getList() {
		
		return allActions;
	}
	
	
	/**
	 * Indicates if any Actions have been
	 * added to the allActions ArrayList. 
	 * 
	 * @return True if the "allActions" ArrayList
	 * has at least one entry, False otherwise.
	 */
	static boolean anyLearned() {
		
		return (!allActions.isEmpty());
	}
	
	/**
	 * Returns the number of "permanent" Actions
	 * as per the "allActions" ArrayList.
	 * 
	 * @return Integer number of "permanent" Actions.
	 */
	static int totalActions() {
		
		return (allActions.size());
	}
	
	
	/**
	 * Searches the "allActions" ArrayList
	 * for a specific Action based on its
	 * ID number. Since ID is output as one-plus-the 
	 * Action's index in the ArrayList,
	 * the input integer of this method is subtracted
	 * by one to match.
	 * 
	 * @param id Integer output ID of the "permanent"
	 * Action to be found.
	 * @return Action corresponding to the input ID 
	 * integer.
	 */
	static Action getAction(int id) {
		
		if (((id - 1) < allActions.size()) && (id > 0)) {
			
			return allActions.get(id - 1);
		} else {
			
			throw new IllegalArgumentException("Action no exist!");
		}
	}
	
	
	/**
	 * Retrieves a "permanent" Action from
	 * the "allActions" ArrayList based on
	 * the alleged Action's "name" variable.
	 * Throws an exception if no Action with
	 * the input name is found.
	 * 
	 * @param name String of the desired Action's
	 * "name" variable.
	 * @return Action with the input name, if 
	 * any.
	 */
	static Action getAction(String name) {
		
		for (int a = 0; a < allActions.size(); a++) {
			
			if (allActions.get(a).getName().equals(name)) {
				
				return allActions.get(a);
			} else {}
		}
		
		throw new IllegalArgumentException("Action not found!");
	}
	
	
	
	/**
	 * Searches the allAcitons ArrayList
	 * for an unlearned Action associated 
	 * with an input Stat object. The 
	 * first time it finds one, it marks
	 * the Action learned and returns it.
	 * If no Actions are found that meet
	 * the criteria, throws an error.
	 * 
	 * @param stat Stat associated with
	 * target Action.
	 * @return Action found and marked
	 * learned by this method.
	 */
	static Action learnFromStat(Stat stat) {
		
		for (int a = 0; a < allActions.size(); a++) {
			
			if (((allActions.get(a)).getStat().equals(stat)) 
					&& (!((allActions.get(a)).isLearned()))) {
				
				(allActions.get(a)).learn();
				
				return (allActions.get(a));
			} else {}
		}
		
		throw new IllegalArgumentException("Action not found!");
	}
	
	
	/**
	 * Retrieves a "permanent" Action from 
	 * the "allAction" ArrayList based on an
	 * input number. This intended to be used 
	 * by other classes to search for Actions
	 * that fit certain criteria.
	 * 
	 * @param number Integer index of the 
	 * "allActions" ArrayList.
	 * @return Action indexed at the input
	 * integer.
	 */
	static Action findAction(int number) {
		
		if (number < allActions.size()) {
			
			return allActions.get(number);
		} else {
			
			return null;
		}
	}
	
	
	/**
	 * Facilitates the individual effects
	 * of each Action currently
	 * in the game. Each potential Action
	 * is constructed within other methods 
	 * such that it will have an ID value
	 * corresponding to a case in this 
	 * method's Switch statement. The 
	 * Action's user's level and the Action's 
	 * Stat's "Modded level" parameters are 
	 * internally stored as variables for
	 * convenience and readability, as 
	 * many Actions use one or both for
	 * scaling.
	 * 
	 * @param action Action to be used.
	 */
	public static String doAction(Action action) {
	
		if (!action.isUsable()) {
			
			throw new IllegalArgumentException(action.errorMessage());
		}
		
		int heroLevel = action.getUser().getLevel();
		int statLevel = action.getStat().getModdedLevel();
		String output = new String();
		Monster target = Action.getTarget();
		target.prepare();
		
		switch (action.getId()) {
			
		case 1: {
		//The "Lunge" weapon Skill.	
			output = (action.quickUse((Scaler.damage(heroLevel,((int)(statLevel * 1.5)))), target));
			//Lunge has a lower damage floor, but also a higher ceiling (to represent a desperation attack)
			if ((target.getHealth()) <= 0) {
			//if target is dead, they cannot mutual-kill (unless they crit)
				target.stun();
			} else {}
		break;
		}
		
		case 2: {
		//The "Counter" shield Skill.	
			int damage = Scaler.damage(heroLevel);
				//has relatively weak scaling
			output = (action.quickUse(damage, target));
		
			target.setDamage(target.getDamage() - damage);
		break;
		}
		
		case 3: {
		//The "Mana Burst" weapon Skill.	
			int manaCost = ((int)(((Hero)action.getUser()).getMaxMana() * .5));
			
			if (((Hero)action.getUser()).getMana() >= manaCost) {
				
				output = (action.quickUse((Scaler.damage(((int)(statLevel * 1.5)), statLevel)), target));
				//scales very well
				((Hero)action.getUser()).spendMana(manaCost);
				
			} else if ((Action.getAction("Ascend")).isLearned()) {
				
				output = ("You sacrifice " + action.getUser().harm(Scaler.damage(action.getStat())) +
				 " health to abstract your " + action.getImplement() + ",\n and strike for " +
				 target.harm(Scaler.damage(((int)(statLevel * 1.5)), statLevel)) + " damage!\n");

				((Skill)action).setCooldown();
				//shouldn't do anything but it just seemed proper
			} else {
				
				throw new IllegalArgumentException("No Mana to Burst.");
			}
		break;	
		}
		
		case 4: {
		//The "Shield Bash" shield Skill.
			output = (action.quickUse(Scaler.damage(statLevel), target));
			
			if ((new Random().nextBoolean())) {
				
				target.stun();
				
				((Skill)action).setCooldown();
			} else {}
		break;	
		}
		
		case 5: {
		//The "Drain" Spell.
			
			int cure = Scaler.damage(heroLevel);
			//low floor and flux due to how good this spell is
			target.setDamage((target.getDamage()) - cure);
		
			output = (action.getMessage((action.getUser().heal(cure)), target));
			
			((Spell)action).spendMana();
		break;
		}
		
		case 6: {
		//The "Bolt" Spell	
			output = (action.quickUse(Scaler.damage(statLevel), target));
		break;
		}
		
		case 7: {
		//The "Ascend" Spell
			output = (action.quickUse((Scaler.damage(heroLevel)),action.getUser()));
			//"trust no one, not even yourself"
			int upMana = (int)(((Hero)action.getUser()).getMaxMana() * .5);
			
			((Hero)action.getUser()).upMana(upMana);
			
			output += (" restoring " + upMana + " Mana!\n");
		break;
		}
		
		case 8: {
		//The "Revert" Spell	
			int damage = Scaler.damage((statLevel + action.getStat().getLevel()),heroLevel);
			
			output = (action.getMessage(damage));
			
			action.getUser().heal(damage);
			
			((Spell)action).spendMana();
		break;
		}
		
		case 9: {
		//The "Astra" Spell
			int stars = (new Random().nextInt(((Hero)action.getUser()).getMana() / (action.getCost())) + 1);
			
			if (stars <= 0) {
				
				output = ("The Stars cross against the Hero!\n No damage dealt...");
				//spell has a chance to fail.
			} else {
			
				int damage = 0;
				
				for (int s = 0; s < stars; s++) {
					
					damage += (Scaler.damage(1, (int)(statLevel * 2.5)));
				}
				
				if (stars == 1) {
					
					output = "A Star crosses ";
				} else {
					/*thank goodness this isnt a commercial project that required
					localization or else I'd probably need to make (or find)
					an object to dynamically handle plural conjugation lol*/
					output = (stars + " Stars cross ");
				}
				
				output += (((Spell)action).quickUse(damage, target) + "\n");
				
				((Hero)action.getUser()).spendMana((stars - 1) * action.getCost());
				//spends the extra mana from the additional stars
			}	
	
		break;	
		}
		
		default: {
		//intended for the basic attack
			output = (action.quickUse(Scaler.damage(statLevel), target));
		break;
		}
		
		}
		
		return output;
	}
	
	
	/**
	 * Abstract method indicating if the Action can be used.
	 * As this may involve the resource costs and other
	 * restrictions of subclasses, this is left abstract for
	 * them to define. In most cases, should return False 
	 * regardless of other considerations if the Action is 
	 * unlearned.
	 * 
	 * @return True if the Action can currently be used,
	 * False otherwise.
	 */
	abstract boolean isUsable();
	
	
	/**
	 * Abstract method returning a String with info on
	 * the specific Action, intended for use in a list of 
	 * possible Actions. Should include the name as well
	 * as resource cost and other relevant use info. As this 
	 * info will depend on the Action's subclass, the 
	 * method is left abstract.
	 * 
	 * @return String with info on the use of the Action.
	 */
	abstract String menuMessage();
	
	
	/**
	 * Abstract method used to provide String descriptions
	 * for exceptions thrown as a result of invalid Actions.
	 * As usability is a factor, this method is left abstract. 
	 * 
	 * @return String description of why this Action is
	 * unusable.
	 */
	abstract String errorMessage();
	
	
	/**
	 * Abstract method meant to consolidate "common" methods
	 * used by Action subclasses, such as damage protocol
	 * and resource manipulation. These methods are called, and
	 * a String (intended to be the Action's most specific use
	 * message) is output. This String is not printed by the 
	 * object's method itself in order to give more formatting 
	 * control to invoking methods. An integer value for damage and a 
	 * Fighter target are called for, under the assumption that 
	 * they will be needed for damage and message protocol, but may
	 * be left unused by the subclass's override if they are 
	 * unnecessary. 
	 * 
	 * @param damage Integer as defined by subclass.
	 * @param target Fighter as defined by subclass.
	 * @return String as defined by subclass.
	 */
	abstract String quickUse(int damage, Fighter target);
}