/**
 * Concrete Gear subclass meant to represent an off-hand
 * shield weilded by a Fighter. Intended to define and 
 * scale certain Skill objects. Implements HealthScale
 * to affect an associated Fighter's Health parameter.
 * As with all Stat subclasses, the level parameter and 
 * the static maxLevel value are facilitated via a Gauge
 * object, and thus the Gauge class is necessary
 * for instantiating any objects of this class.
 * 
 * @author Kayden Barlow
 */
public class Shield extends Gear implements HealthScale {

	
	/**
	 * Constructor for instances of the Shield
	 * class. Must be assigned to an 
	 * instance of the Fighter class, and will
	 * be added to that Fighter's ArrayList
	 * of stats. The name parameter will be fixed
	 * as "Shield".
	 * 
	 * @param user Fighter to which the Stat
	 * is assigned.
	 * @param level Integer value of the Stat's
	 * relative power.
	 */
	Shield(Fighter user, int level) {
		
		super(user, "Shield", level, new String[] {"Bare hand", "Buckler", "Targe", "Heater"});
	}
	
	
	/**
	 * Creates a instance of this object with
	 * a level parameter of zero. As the superclass
	 * constructor automatically adds new Stat objects
	 * to the Fighter's list of stats, this is intended
	 * to be used to quickly add a new, generic Shield
	 * Gear Stat to the input Fighter.
	 * 
	 * @param user Fighter to receive a new instance
	 * of this object.
	 */
	public static void add(Fighter user) {
		
		new Shield(user, 0);
	}
	
	
	/**
	 * As required by the HealthScale interface,
	 * returns a value intended to scale the 
	 * maxHealth parameter of this object's associated
	 * Fighter instance. In this case, it returns
	 * two times the value of the level paramwter
	 * of this object.
	 * 
	 * @return Integer scaled from this Shield object's
	 * level.
	 */
	public int healthScale() {
		
		return (this.getLevel() * 2);
	}
}
